import os
import sys
import shutil
from fastapi import FastAPI, Request, File, UploadFile, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.loaders import load_pdf, load_text, load_csv
from src.chunkers import recursive_splitter
from src.vectorstore import create_vectorstore
from src.retrievers import similarity_retriever
from src.chains import create_rag_chain
from src.models import llm, embeddings

app = FastAPI(title="RAG Assistant")
templates = Jinja2Templates(directory=os.path.join(os.path.dirname(__file__), "templates"))

UPLOAD_FOLDER = './data/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

vectorstore = None
rag_chain = None

if not llm or not embeddings:
    print("Error: OpenAI API key not configured. Please set OPENAI_API_KEY in .env file.")

class QueryRequest(BaseModel):
    question: str

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request=request, name="index.html")

@app.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    global vectorstore, rag_chain
    if not file.filename:
        raise HTTPException(status_code=400, detail="No selected file")
    
    filepath = os.path.join(UPLOAD_FOLDER, file.filename)
    with open(filepath, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    try:
        # Load documents based on file type
        if file.filename.lower().endswith('.pdf'):
            docs = load_pdf(filepath)
        elif file.filename.lower().endswith('.txt'):
            docs = load_text(filepath)
        elif file.filename.lower().endswith('.csv'):
            docs = load_csv(filepath)
        else:
            raise HTTPException(status_code=400, detail="Unsupported file type (.pdf, .txt, .csv only)")

        # Chunk documents
        chunks = recursive_splitter(docs)

        # Create vectorstore
        persist_directory = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'chroma_db')
        vectorstore = create_vectorstore(chunks, persist_dir=persist_directory)

        # Create retriever and chain
        retriever = similarity_retriever(vectorstore)
        rag_chain = create_rag_chain(retriever)

        return {"message": f"Document '{file.filename}' processed successfully! You can now ask questions."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/query")
async def query(req: QueryRequest):
    global rag_chain
    if not rag_chain:
        raise HTTPException(status_code=400, detail="Please upload a document first.")

    try:
        answer = rag_chain.invoke(req.question)
        return {"answer": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
